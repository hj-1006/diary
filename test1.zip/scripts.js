const fs = require('fs');

document.addEventListener('DOMContentLoaded', (event) => {
    const diaryForm = document.getElementById('diaryForm');
    const diaryEntry = document.getElementById('diaryEntry');
    const entriesDiv = document.getElementById('entries'); 
    const imageInput = document.getElementById('imageInput'); // 이미지 변수

    diaryForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const entryContent = diaryEntry.value;
        const imageData = imageInput.files[0]; // 이미지 파일 가져오기
        addEntry(entryContent, imageData);
        diaryEntry.value = '';
    });

    function addEntry(entry, imageData) {
        if (entry) {
            const entryDiv = document.createElement('div');
            entryDiv.classList.add('entry');
            
            // 일기 내용 추가
            const entryContent = document.createElement('p');
            entryContent.textContent = entry;
            entryDiv.appendChild(entryContent);
            
            // 이미지 추가
            if (imageData) {
                const image = document.createElement('img');
                image.src = URL.createObjectURL(imageData);
                image.classList.add('entry-image');
                entryDiv.appendChild(image);
            }
            
            // 작성 시간 추가
            const timestamp = new Date().toLocaleString();
            const timestampSpan = document.createElement('span');
            timestampSpan.classList.add('timestamp');
            timestampSpan.textContent = timestamp;
            entryDiv.appendChild(timestampSpan);
            
            // 단일 지우기 버튼 추가
            const deleteButton = document.createElement('button');
            deleteButton.classList.add('deleteButton');
            deleteButton.textContent = '삭제';
            deleteButton.addEventListener('click', () => {
                deleteEntry(entryDiv);
            });
            entryDiv.appendChild(deleteButton);
            
            entriesDiv.appendChild(entryDiv);
            saveEntryToJSON({ content: entry, image: imageData ? URL.createObjectURL(imageData) : null, timestamp: timestamp });
        }
    }

    function deleteEntry(entryDiv) {
        entryDiv.remove();
        // 필요한 경우 여기에 삭제된 일기를 JSON 파일에서도 삭제하는 코드를 추가할 수 있습니다.
    }
    
    function saveEntryToJSON(entry) {
        let entries = getEntriesFromJSON();
        entries.push(entry);
        fs.writeFileSync('entries.json', JSON.stringify(entries, null, 2));
    }

    function getEntriesFromJSON() {
        try {
            const data = fs.readFileSync('entries.json');
            return JSON.parse(data);
        } catch (error) {
            return [];
        }
    }

    function loadEntries() {
        let entries = getEntriesFromJSON();
        entries.forEach((entry) => {
            addEntry(entry.content, entry.image ? entry.image : null);
        });
    }

    loadEntries();
});
