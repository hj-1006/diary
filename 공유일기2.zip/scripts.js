const diaryForm = document.getElementById('diaryForm');
const diaryEntry = document.getElementById('diaryEntry');
const entriesDiv = document.getElementById('entries');

diaryForm.addEventListener('submit', (e) => {
    e.preventDefault();
    addEntry(diaryEntry.value);
    diaryEntry.value = '';
});

function addEntry(entry) {
    if (entry) {
        const entryDiv = document.createElement('div');
        entryDiv.classList.add('entry');
        entryDiv.textContent = entry;
        entriesDiv.appendChild(entryDiv);
        saveEntry(entry);
    }
}

function saveEntry(entry) {
    let entries = getEntries();
    entries.push(entry);
    localStorage.setItem('entries', JSON.stringify(entries));
}

function getEntries() {
    let entries = localStorage.getItem('entries');
    if (entries) {
        return JSON.parse(entries);
    } else {
        return [];
    }
}

function loadEntries() {
    let entries = getEntries();
    entries.forEach((entry) => {
        addEntry(entry);
    });
}

loadEntries();