const express = require('express');
const bodyParser = require('body-parser');
const redis = require('redis');
const app = express();
const port = 3000;

// Redis 클라이언트 설정
const client = redis.createClient({
    host: 'redis', // 도커 컴포즈 서비스 이름 사용
    port: 6379
});

client.on('error', (err) => {
    console.error('Redis error:', err);
});

// 미들웨어 설정
app.use(bodyParser.json({ limit: '10mb' })); // JSON 바디 크기 제한 증가
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static('client'));

// CORS 설정 (필요시 사용)
// app.use((req, res, next) => {
//     res.header("Access-Control-Allow-Origin", "*");
//     res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
//     next();
// });

// 일기 항목 가져오기
app.get('/entries', (req, res) => {
    client.lrange('entries', 0, -1, (err, entries) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.send(entries.map(entry => JSON.parse(entry)));
    });
});

// 일기 항목 추가하기
app.post('/entries', (req, res) => {
    const { entry, image, time } = req.body;
    const newEntry = JSON.stringify({ entry, image, time });
    client.rpush('entries', newEntry, (err) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(201).send('Entry added');
    });
});

// 일기 항목 삭제하기
app.post('/delete', (req, res) => {
    const { entry, image, time } = req.body;
    const entryToDelete = JSON.stringify({ entry, image, time });
    client.lrem('entries', 0, entryToDelete, (err) => {
        if (err) {
            return res.status(500).send(err);
        }
        res.status(200).send('Entry deleted');
    });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});

